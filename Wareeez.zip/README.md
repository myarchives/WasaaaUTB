# Wareeez

Wareeez is a plugin for AVideo to let you access your videos stored on Uptobox.com

## Usage

If you need an explanation on how to use this plugin please read [my article on medium](https://medium.com/@nazimboudeffa/wasabi-plugin-for-youphptube-6f024cf12ff1?source=friends_link&sk=a6f3c6f3f0b79618fd17f148a26000d3) it works exactly the same as Wasaaa but as you can see it has a different meaning as I am sure at 99% that you'll use it for that kind of activity, so please be aware that there are laws about this activity and that Uptobox use to know that and will probably act against a bad usage of their service, you'll see also what are the limitations of the licence

## About

Wareeez is free like in **free beer** or [name your own price](todo)

[![Wareeez](Wareeez.gif)](https://fr.tipeee.com/nazimboudeffa#reward-300065)
